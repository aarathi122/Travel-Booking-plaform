package AuctionSystem;

public interface AuctionObserver {
	 void update(String auctionItem, String message);
}
