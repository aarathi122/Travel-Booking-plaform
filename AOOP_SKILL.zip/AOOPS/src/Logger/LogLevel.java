package Logger;

public enum LogLevel {
	 INFO, DEBUG, ERROR 
}
