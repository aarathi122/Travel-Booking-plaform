package MUSICPLAYER;

public class OnlineStreamingService {
	  public void streamMusic() {
	  System.out.println("Streaming music online.");
	    }
}
