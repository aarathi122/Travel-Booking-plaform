package MUSICPLAYER;

public interface MediaSource {
void paly();
}
