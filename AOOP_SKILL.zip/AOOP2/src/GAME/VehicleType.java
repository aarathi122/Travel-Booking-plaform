package GAME;

public enum VehicleType {
	CAR, BIKE, SCOOTER;
}
