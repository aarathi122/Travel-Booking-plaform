package StudentInformation;

public class Course {
	private String id;
    private String name;
	public Course(String id, String name) {
		  this.id = id;
	        this.name = name;
			}
	public String getId() {
        return id;
    }
    public String getName() {
        return name;
    }

}
