package com.DP;

public interface MusicSource {
    void playMusic();
}
