package com.DP;

public interface PaymentMethod {
    void pay(double amount);
}
