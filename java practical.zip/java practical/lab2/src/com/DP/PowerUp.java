package com.DP;

public interface PowerUp {
    void activate();
}
