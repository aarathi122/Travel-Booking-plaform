package com.DP;

public class HealthPowerUp implements PowerUp {
    @Override
    public void activate() {
        System.out.println("Health power-up activated!");
    }

}
