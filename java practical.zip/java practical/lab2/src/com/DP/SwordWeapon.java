package com.DP;

public class SwordWeapon implements Weapon {
    @Override
    public void use() {
        System.out.println("Sword weapon used!");
    }

}
